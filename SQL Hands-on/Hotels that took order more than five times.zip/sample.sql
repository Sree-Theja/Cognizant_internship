select h.hotel_id,h.hotel_name,count(o.order_id) as NO_OF_ORDERS from hotel_details h
inner join orders o on h.hotel_id=o.hotel_id group by h.hotel_id,h.hotel_name having count(o.order_id)>5;