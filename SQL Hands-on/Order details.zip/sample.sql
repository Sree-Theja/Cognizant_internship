select o.order_id,c.customer_name,h.hotel_name,o.order_amount from orders o 
join customers c on c.customer_id=o.customer_id join hotel_details h on o.hotel_id=h.hotel_id
group by o.order_id asc;